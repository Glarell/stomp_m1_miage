# stomp_m1_miage

## Développer un serveur implémentant le protocole STOMP en JAVA.

Le protocole STOMP permet à plusieurs acteurs de communiquer en utilisant le
paradigme publish/subscribe. Un client publie une information sur un topic, tous les
clients abonnés à ce topic reçoivent l’information.
C’est un protocole textuel assez simple décrit en détail là -> https://stomp.github.io/
stomp-specification-1.2.html

### Contributors
- CISTERNINO Enzo
- TONDON César
- XU François
